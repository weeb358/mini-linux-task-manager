// taskmgr.h
#ifndef TASKMGR_H
#define TASKMGR_H

#define _DEFAULT_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/sysinfo.h>
#include <signal.h>
#include <time.h>
#include <pthread.h>
#include <sys/mman.h>
#include <semaphore.h>

#define MAX_PROCESSES 200
#define MAX_TASKS 50

typedef struct {
    int pid;
    char name[256];
    int threads;
    long long memory_kb;
} ProcessInfo;

typedef struct {
    int task_id;
    char name[50];
    int burst_time;
    int remaining_time;
    pid_t real_pid;
} Task;

typedef struct {
    ProcessInfo procs[MAX_PROCESSES];
    int proc_count;
    Task tasks[MAX_TASKS];
    int task_count;
    pthread_mutex_t lock;
    sem_t sched_sem;
    volatile int should_exit;
    char schedule_request;
    volatile int schedule_requested;
    int sort_by; // 0=PID, 1=Name, 2=Memory
} SharedData;

// Function declarations
int read_all_processes(ProcessInfo *procs);
void get_system_memory(long long *total_kb, long long *used_kb);
long long get_total_memory_kb(void);
long long get_memory_usage_kb(int pid);
int get_thread_count(int pid);
int get_process_name(int pid, char *name, size_t size);

// Sorting comparators (for monitor.c)
int compare_by_name(const void *a, const void *b);
int compare_by_memory(const void *a, const void *b);

void *monitor_thread_func(void *arg);
void *scheduling_thread_func(void *arg);
void launch_real_task(SharedData *data, char *cmd);
void kill_process_by_pid(SharedData *data, int pid);
void simulate_scheduling_logic(SharedData *data, char algo);

#endif
