// monitor.c
#include "taskmgr.h"

void *monitor_thread_func(void *arg) {
    SharedData *data = (SharedData *)arg;
    ProcessInfo temp[MAX_PROCESSES];
    while (!data->should_exit) {
        int count = read_all_processes(temp);

        // Apply sorting based on sort_by
        if (data->sort_by == 1) {
            qsort(temp, count, sizeof(ProcessInfo), compare_by_name);
        } else if (data->sort_by == 2) {
            qsort(temp, count, sizeof(ProcessInfo), compare_by_memory);
        }
        // sort_by == 0 → keep natural order (by PID)

        pthread_mutex_lock(&data->lock);
        data->proc_count = (count < MAX_PROCESSES) ? count : MAX_PROCESSES - 1;
        for (int i = 0; i < data->proc_count; i++) {
            data->procs[i] = temp[i];
        }
        pthread_mutex_unlock(&data->lock);
        sleep(1);
    }
    return NULL;
}
