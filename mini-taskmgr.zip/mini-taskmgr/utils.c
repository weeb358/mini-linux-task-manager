// utils.c
#define _DEFAULT_SOURCE
#include "taskmgr.h"
#include <pwd.h>

static void safe_strcpy(char *dest, const char *src, size_t size) {
    if (!dest || !src || size == 0) {
        if (dest && size > 0) dest[0] = '\0';
        return;
    }
    size_t len = strlen(src);
    if (len >= size) len = size - 1;
    memcpy(dest, src, len);
    dest[len] = '\0';
}

long long get_total_memory_kb(void) {
    struct sysinfo info;
    return (sysinfo(&info) == 0) ? (info.totalram * info.mem_unit) / 1024 : 1;
}

long long get_memory_usage_kb(int pid) {
    if (pid <= 0) return 0;
    char path[256];
    snprintf(path, sizeof(path), "/proc/%d/status", pid);
    FILE *file = fopen(path, "r");
    if (!file) return 0;
    char line[512];
    long long vmrss = 0;
    while (fgets(line, sizeof(line), file)) {
        if (strncmp(line, "VmRSS:", 6) == 0) {
            sscanf(line + 6, "%lld", &vmrss);
            break;
        }
    }
    fclose(file);
    return vmrss;
}

int get_thread_count(int pid) {
    if (pid <= 0) return 1;
    char path[256];
    snprintf(path, sizeof(path), "/proc/%d/stat", pid);
    FILE *file = fopen(path, "r");
    if (!file) return 1;
    int threads = 1;
    for (int i = 0; i < 19; i++) fscanf(file, "%*s");
    fscanf(file, "%d", &threads);
    fclose(file);
    return (threads > 0) ? threads : 1;
}

int get_process_name(int pid, char *name, size_t size) {
    if (pid <= 0 || !name || size == 0) return -1;
    char path[256];
    snprintf(path, sizeof(path), "/proc/%d/comm", pid);
    FILE *file = fopen(path, "r");
    if (!file) return -1;
    if (fgets(name, (int)size, file)) {
        name[strcspn(name, "\n")] = '\0';
    }
    fclose(file);
    return 0;
}

void get_system_memory(long long *total_kb, long long *used_kb) {
    *total_kb = *used_kb = 0;
    FILE *f = fopen("/proc/meminfo", "r");
    if (!f) return;
    char key[32], line[256];
    long long value;
    while (fgets(line, sizeof(line), f)) {
        if (sscanf(line, "%31s %lld kB", key, &value) == 2) {
            if (strcmp(key, "MemTotal:") == 0) *total_kb = value;
            else if (strcmp(key, "MemFree:") == 0) *used_kb -= value;
            else if (strcmp(key, "Buffers:") == 0) *used_kb -= value;
            else if (strcmp(key, "Cached:") == 0) *used_kb -= value;
        }
    }
    fclose(f);
    *used_kb = (*total_kb > 0) ? (*total_kb + *used_kb) : 0;
}

int is_user_process(int pid) {
    if (pid <= 0) return 0;
    char path[256];
    snprintf(path, sizeof(path), "/proc/%d/status", pid);
    FILE *f = fopen(path, "r");
    if (!f) return 0;
    char line[256];
    unsigned long uid = (unsigned long)-1;
    while (fgets(line, sizeof(line), f)) {
        if (strncmp(line, "Uid:", 4) == 0) {
            sscanf(line + 4, "%lu", &uid);
            break;
        }
    }
    fclose(f);
    return (uid != (unsigned long)-1 && uid >= 1000);
}

int read_all_processes(ProcessInfo *procs) {
    if (!procs) return 0;
    DIR *dir = opendir("/proc");
    if (!dir) return 0;
    struct dirent *entry;
    int count = 0;
    while ((entry = readdir(dir)) != NULL && count < MAX_PROCESSES - 1) {
        if (entry->d_type != DT_DIR) continue;
        long pid = strtol(entry->d_name, NULL, 10);
        if (pid <= 0 || pid > 65535) continue;
        char name[256];
        if (get_process_name(pid, name, sizeof(name)) != 0) continue;
        if (name[0] == '[') continue;
        if (!is_user_process(pid)) continue;
        ProcessInfo p;
        p.pid = (int)pid;
        safe_strcpy(p.name, name, sizeof(p.name));
        p.threads = get_thread_count(pid);
        p.memory_kb = get_memory_usage_kb(pid);
        procs[count++] = p;
        if (count >= 25) break;
    }
    closedir(dir);
    return count;
}

// === SORTING COMPARATORS ===
int compare_by_name(const void *a, const void *b) {
    return strcmp(((ProcessInfo*)a)->name, ((ProcessInfo*)b)->name);
}

int compare_by_memory(const void *a, const void *b) {
    long long mem_a = ((ProcessInfo*)a)->memory_kb;
    long long mem_b = ((ProcessInfo*)b)->memory_kb;
    if (mem_a > mem_b) return -1;
    if (mem_a < mem_b) return 1;
    return 0;
}
