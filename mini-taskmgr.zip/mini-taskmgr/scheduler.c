// scheduler.c
#include "taskmgr.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

void launch_real_task(SharedData *data, char *cmd) {
    if (!data || !cmd || cmd[0] == '\0') return;
    int len = strlen(cmd);
    while (len > 0 && (cmd[len-1] == ' ' || cmd[len-1] == '\t')) cmd[--len] = '\0';
    pid_t pid = fork();
    if (pid == 0) {
        execl("/bin/sh", "sh", "-c", cmd, (char *)NULL);
        _exit(1);
    } else if (pid > 0) {
        pthread_mutex_lock(&data->lock);
        if (data->task_count < MAX_TASKS) {
            int idx = data->task_count;
            data->tasks[idx].task_id = idx + 1;
            snprintf(data->tasks[idx].name, sizeof(data->tasks[idx].name), "%.30s", cmd);
            data->tasks[idx].burst_time = 5 + (idx % 3); // Vary burst time
            data->tasks[idx].remaining_time = data->tasks[idx].burst_time;
            data->tasks[idx].real_pid = pid;
            data->task_count++;
        }
        pthread_mutex_unlock(&data->lock);
    }
}

void kill_process_by_pid(SharedData *data, int pid) {
    if (pid <= 0) return;
    pthread_mutex_lock(&data->lock);
    for (int i = 0; i < data->task_count; i++) {
        if (data->tasks[i].real_pid == pid) {
            for (int j = i; j < data->task_count - 1; j++)
                data->tasks[j] = data->tasks[j + 1];
            data->task_count--;
            break;
        }
    }
    pthread_mutex_unlock(&data->lock);
    kill(pid, SIGTERM);
}

// ✅ REAL SCHEDULING LOGIC
void simulate_scheduling_logic(SharedData *data, char algo) {
    Task local_tasks[MAX_TASKS];
    int count;
    pthread_mutex_lock(&data->lock);
    count = data->task_count;
    memcpy(local_tasks, data->tasks, sizeof(Task) * count);
    pthread_mutex_unlock(&data->lock);

    if (count == 0) {
        FILE *log = fopen("/tmp/taskmgr.log", "a");
        if (log) {
            time_t t = time(NULL);
            struct tm *tm = localtime(&t);
            fprintf(log, "[%02d:%02d:%02d] %s | Tasks: 0 | No tasks to schedule\n",
                    tm->tm_hour, tm->tm_min, tm->tm_sec,
                    algo == 'f' ? "FCFS" : algo == 'j' ? "SJF" : "Round Robin");
            fclose(log);
        }
        return;
    }

    // SJF: sort by burst_time
    if (algo == 'j') {
        for (int i = 0; i < count - 1; i++) {
            for (int j = i + 1; j < count; j++) {
                if (local_tasks[i].burst_time > local_tasks[j].burst_time) {
                    Task tmp = local_tasks[i];
                    local_tasks[i] = local_tasks[j];
                    local_tasks[j] = tmp;
                }
            }
        }
    }

    // Build Gantt chart string
    char gantt[512] = "Gantt: |";
    for (int i = 0; i < count; i++) {
        char part[20];
        snprintf(part, sizeof(part), " T%d |", local_tasks[i].task_id);
        strcat(gantt, part);
    }

    // Log with execution order
    FILE *log = fopen("/tmp/taskmgr.log", "a");
    if (log) {
        time_t t = time(NULL);
        struct tm *tm = localtime(&t);
        fprintf(log, "[%02d:%02d:%02d] %s | Tasks: %d | %s\n",
                tm->tm_hour, tm->tm_min, tm->tm_sec,
                algo == 'f' ? "FCFS" : algo == 'j' ? "SJF" : "Round Robin",
                count, gantt);
        fclose(log);
    }
}

// ✅ SCHEDULING THREAD (3rd thread)
void *scheduling_thread_func(void *arg) {
    SharedData *data = (SharedData *)arg;
    while (!data->should_exit) {
        sem_wait(&data->sched_sem); // ✅ Wait for signal
        if (data->should_exit) break;

        pthread_mutex_lock(&data->lock);
        char algo = data->schedule_request;
        data->schedule_requested = 0;
        pthread_mutex_unlock(&data->lock);

        simulate_scheduling_logic(data, algo);
    }
    return NULL;
}
