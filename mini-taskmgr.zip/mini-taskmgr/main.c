// main.c
#include <ncurses.h>
#include "taskmgr.h"
#include <string.h>

static void draw_bar(const char *label, double percent, int y) {
    int width = 30;
    mvprintw(y, 0, "%s: [", label);
    int fill = (int)(percent * (width - 2) / 100.0);
    for (int i = 0; i < width - 2; i++) {
        addch(i < fill ? '=' : ' ');
    }
    printw("] %d%%", (int)percent);
}

static double last_cpu = 0.0;
static unsigned long long last_idle = 0, last_total = 0;

double get_cpu_usage(void) {
    FILE *f = fopen("/proc/stat", "r");
    if (!f) return last_cpu;
    unsigned long long user, nice, sys, idle, iowait, irq, softirq, steal;
    if (fscanf(f, "cpu %llu %llu %llu %llu %llu %llu %llu %llu",
               &user, &nice, &sys, &idle, &iowait, &irq, &softirq, &steal) != 8) {
        fclose(f);
        return last_cpu;
    }
    fclose(f);
    unsigned long long total = user + nice + sys + idle + iowait + irq + softirq + steal;
    unsigned long long idle_time = idle + iowait;
    if (last_total == 0) { last_idle = idle_time; last_total = total; return 0.0; }
    unsigned long long diff_idle = idle_time - last_idle;
    unsigned long long diff_total = total - last_total;
    last_idle = idle_time;
    last_total = total;
    if (diff_total == 0) return last_cpu;
    last_cpu = 100.0 * (diff_total - diff_idle) / diff_total;
    return (last_cpu < 0) ? 0 : (last_cpu > 100 ? 100 : last_cpu);
}

int main(void) {
    SharedData *data = mmap(NULL, sizeof(SharedData), PROT_READ | PROT_WRITE,
                            MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    if (data == MAP_FAILED) return 1;
    memset(data, 0, sizeof(SharedData));
    data->sort_by = 0; // 0=PID, 1=Name, 2=Memory
    pthread_mutex_init(&data->lock, NULL);
    sem_init(&data->sched_sem, 1, 0);

    pthread_t mon_thread, sched_thread;
    if (pthread_create(&mon_thread, NULL, monitor_thread_func, data) != 0) goto cleanup;
    if (pthread_create(&sched_thread, NULL, scheduling_thread_func, data) != 0) goto cleanup;

    initscr(); cbreak(); noecho(); curs_set(0); timeout(500);
    start_color();

    init_pair(1, COLOR_GREEN, COLOR_BLACK);  // header
    init_pair(2, COLOR_WHITE, COLOR_BLACK);  // processes
    init_pair(3, COLOR_YELLOW, COLOR_BLACK); // tasks
    init_pair(4, COLOR_RED, COLOR_BLACK);    // highlight
    init_pair(5, COLOR_CYAN, COLOR_BLACK);   // bars
    init_pair(6, COLOR_GREEN, COLOR_BLACK);  // success

    int input_mode = 0;
    char search_query[64] = {0};
    int color_theme = 0;

    while (1) {
        int ch = getch();
        if (ch == 'q') break;

        long long total_mem, used_mem;
        get_system_memory(&total_mem, &used_mem);
        double cpu = get_cpu_usage();
        double mem_pct = (total_mem > 0) ? (used_mem * 100.0 / total_mem) : 0;

        erase();
        attron(COLOR_PAIR(1));
        mvprintw(0, 0, "🧠 OS Task Manager v5.2 — Search Tasks & Processes");
        mvprintw(1, 0, "📚 [q]=Quit [s]=Schedule [k]=Kill [S]=Sort [/]=Search [C]=Colors");
        attroff(COLOR_PAIR(1));

        attron(COLOR_PAIR(5));
        draw_bar("CPU", cpu, 3);
        draw_bar("MEM", mem_pct, 4);
        attroff(COLOR_PAIR(5));

        attron(COLOR_PAIR(2));
        mvprintw(6, 0, "%-6s %-18s %8s %10s", "PID", "NAME", "THREADS", "MEM(KB)");
        attroff(COLOR_PAIR(2));

        // === DRAW SYSTEM PROCESSES (with search highlight) ===
        pthread_mutex_lock(&data->lock);
        for (int i = 0; i < data->proc_count && i < 20; i++) {
            int highlight = 0;
            if (search_query[0] != '\0') {
                if (strstr(data->procs[i].name, search_query)) {
                    highlight = 1;
                    attron(COLOR_PAIR(4));
                }
            }
            mvprintw(7 + i, 0, "%-6d %-18s %8d %10lld",
                     data->procs[i].pid, data->procs[i].name,
                     data->procs[i].threads, data->procs[i].memory_kb);
            if (highlight) attroff(COLOR_PAIR(4));
        }

        // === DRAW SCHEDULED TASKS (with search highlight) ===
        if (data->task_count > 0) {
            mvprintw(28, 0, "📌 Scheduled Tasks:");
            for (int i = 0; i < data->task_count && i < 5; i++) {
                int task_highlight = 0;
                if (search_query[0] != '\0') {
                    if (strstr(data->tasks[i].name, search_query)) {
                        task_highlight = 1;
                        attron(COLOR_PAIR(4)); // same red highlight
                    }
                }
                mvprintw(29 + i, 0, "T%d: %s (PID: %d)",
                         data->tasks[i].task_id, data->tasks[i].name, data->tasks[i].real_pid);
                if (task_highlight) attroff(COLOR_PAIR(4));
            }
        }
        pthread_mutex_unlock(&data->lock);

        // Clear feedback/input lines
        mvprintw(35, 0, "                                                                ");
        mvprintw(36, 0, "                                                                ");

        // === INPUT HANDLING ===
        if (input_mode == 1) {
            mvprintw(35, 0, "Run command: ");
            clrtoeol();
            char cmd[256] = {0}; int pos = 0;
            curs_set(1); timeout(-1);
            while (1) {
                int c = getch();
                if (c == '\n' || c == KEY_ENTER) break;
                if (c == 127 || c == '\b') {
                    if (pos > 0) { pos--; mvaddch(35, 12 + pos, ' '); move(35, 12 + pos); }
                } else if (c >= 32 && c <= 126 && pos < 254) {
                    cmd[pos++] = (char)c; addch(c);
                }
                refresh();
            }
            mvprintw(35, 0, "                                                                ");
            cmd[pos] = '\0';
            if (cmd[0] != '\0') {
                launch_real_task(data, cmd);
                attron(COLOR_PAIR(6));
                mvprintw(36, 0, "✅ Launched: %.30s", cmd);
                attroff(COLOR_PAIR(6));
            }
            input_mode = 0; timeout(500); curs_set(0); refresh();

        } else if (input_mode == 2) {
            mvprintw(35, 0, "Kill PID: ");
            clrtoeol();
            char buf[32] = {0}; int pos = 0;
            curs_set(1); timeout(-1);
            while (1) {
                int c = getch();
                if (c == '\n' || c == KEY_ENTER) break;
                if (c == 127 || c == '\b') {
                    if (pos > 0) { pos--; mvaddch(35, 10 + pos, ' '); move(35, 10 + pos); }
                } else if (c >= '0' && c <= '9' && pos < 30) {
                    buf[pos++] = (char)c; addch(c);
                }
                refresh();
            }
            mvprintw(35, 0, "                                                                ");
            buf[pos] = '\0';
            if (buf[0] != '\0') {
                int pid = atoi(buf);
                if (pid > 0) {
                    kill_process_by_pid(data, pid);
                    attron(COLOR_PAIR(4));
                    mvprintw(36, 0, "💥 Process %d killed!", pid);
                    attroff(COLOR_PAIR(4));
                }
            }
            input_mode = 0; timeout(500); curs_set(0); refresh();

        } else if (input_mode == 3) { // Search mode
            mvprintw(35, 0, "Search: ");
            clrtoeol();
            char query[64] = {0}; int pos = 0;
            curs_set(1); timeout(-1);
            while (1) {
                int c = getch();
                if (c == '\n' || c == KEY_ENTER) break;
                if (c == 127 || c == '\b') {
                    if (pos > 0) { pos--; mvaddch(35, 8 + pos, ' '); move(35, 8 + pos); }
                } else if (c >= 32 && c <= 126 && pos < 62) {
                    query[pos++] = (char)c; addch(c);
                }
                refresh();
            }
            mvprintw(35, 0, "                                                                ");
            query[pos] = '\0';

            // ✅ SAFE COPY — NO WARNING
            int len = strlen(query);
            if (len >= (int)sizeof(search_query)) 
                len = sizeof(search_query) - 1;
            memcpy(search_query, query, len);
            search_query[len] = '\0';

            input_mode = 0; 
            timeout(500); 
            curs_set(0); 
            refresh();

        } else {
            if (ch == 's') input_mode = 1;
            else if (ch == 'k') input_mode = 2;
            else if (ch == '/') input_mode = 3;
            else if (ch == 'S') {
                pthread_mutex_lock(&data->lock);
                data->sort_by = (data->sort_by + 1) % 3;
                pthread_mutex_unlock(&data->lock);
                char *sorts[] = {"PID", "Name", "Memory"};
                mvprintw(36, 0, "✨ Sorted by: %s", sorts[data->sort_by]);
                refresh();
            }
            else if (ch == 'C') {
                color_theme = (color_theme + 1) % 3;
                if (color_theme == 0) {
                    init_pair(1, COLOR_GREEN, COLOR_BLACK);
                    init_pair(2, COLOR_WHITE, COLOR_BLACK);
                } else if (color_theme == 1) {
                    init_pair(1, COLOR_CYAN, COLOR_BLACK);
                    init_pair(2, COLOR_YELLOW, COLOR_BLACK);
                } else {
                    init_pair(1, COLOR_WHITE, COLOR_BLACK);
                    init_pair(2, COLOR_GREEN, COLOR_BLACK);
                }
                mvprintw(36, 0, "🎨 Color theme %d", color_theme + 1);
                refresh();
            }
            else if (ch == 'f' || ch == 'j' || ch == 'r') {
                pthread_mutex_lock(&data->lock);
                data->schedule_request = ch;
                data->schedule_requested = 1;
                pthread_mutex_unlock(&data->lock);
                sem_post(&data->sched_sem);
                mvprintw(36, 0, "✨ Scheduling: %s",
                         ch == 'f' ? "FCFS" : ch == 'j' ? "SJF" : "Round Robin");
                refresh();
            }
        }

        refresh();
    }

    data->should_exit = 1;
    sem_post(&data->sched_sem);
    pthread_join(mon_thread, NULL);
    pthread_join(sched_thread, NULL);
    pthread_mutex_destroy(&data->lock);
    sem_destroy(&data->sched_sem);
    endwin();
    munmap(data, sizeof(SharedData));
    return 0;

cleanup:
    munmap(data, sizeof(SharedData));
    return 1;
}
